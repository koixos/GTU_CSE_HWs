import java.util.Scanner;

public class Main {
    private static final int SIZE = 100;

    private static int toInt(String word) {
        int number = 0;
        for (int i = 0; i < word.length(); i++) {
            int pow = 1;
            for (int j = i; j < word.length() - 1; j++)
                pow *= 10;
            number += (word.charAt(i) - 48) * pow;
        }
        return number;
    }

    private static int validateInput(String[] words) {
        for (String word : words)
            if (word.isEmpty())
                return -999;
        return 999;
    }

    private static int validateId(int id,  CorporateCustomer[] corporateCustomers, RetailCustomer[] retailCustomers, Operator[] operators) {
        if (validateInt(id) == -999)
            return -999;

        for (Operator operator : operators)
            if (operator != null && operator.getId() == id)
                return -999;

        for (CorporateCustomer corporateCustomer : corporateCustomers)
            if (corporateCustomer != null && corporateCustomer.getId() == id)
                return -999;

        for (RetailCustomer retailCustomer : retailCustomers)
            if (retailCustomer != null && retailCustomer.getId() == id)
                return -999;

        return 999;
    }

    private static int validateInt(int number) {
        if (number > 0 && number < 2147483647)
            return 999;
        return -999;
    }

    private static int searchAndFind(int id, CorporateCustomer[] corporateCustomers, RetailCustomer[] retailCustomers, Operator[] operators) {
        if (id <= 0)
            return -999;

        for (Operator operator : operators) {
            if (operator != null && operator.getId() == id) {
                operator.printOperator();
                return 999;
            }
        }

        for (RetailCustomer retailCustomer : retailCustomers) {
            if (retailCustomer != null && retailCustomer.getId() == id) {
                retailCustomer.printCustomer(999);
                return 999;
            }
        }

        for (CorporateCustomer corporateCustomer : corporateCustomers) {
            if (corporateCustomer != null && corporateCustomer.getId() == id) {
                corporateCustomer.printCustomer(999);
                return 999;
            }
        }

        return -999;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] content = FileOps.read("content.txt");

        Order[] orders = new Order[SIZE];
        Operator[] operators = new Operator[SIZE];
        RetailCustomer[] retailCustomers = new RetailCustomer[SIZE];
        CorporateCustomer[] corporateCustomers = new CorporateCustomer[SIZE];

        int ordCtr = 0,
            opCtr = 0,
            rCustCtr = 0,
            cCustCtr = 0;

        for (String line : content) {
            if (line != null) {
                String[] words = FileOps.splitLine(";", line);
                int isValid = validateInput(words);
                if (isValid != -999) {
                    switch (words[0]) {
                        case "order" -> {
                            if (words.length == 6) {
                                int count = toInt(words[2]),
                                    totalPrice = toInt(words[3]),
                                    status = toInt(words[4]),
                                    customerId = toInt(words[5]);
                                if (validateInt(count) == -999 || validateInt(totalPrice) == -999 || validateInt(customerId) == -999)
                                    break;
                                orders[ordCtr] = new Order(words[1], count, totalPrice, status, customerId);
                                ordCtr++;
                            }
                        }
                        case "operator" -> {
                            if (words.length == 7) {
                                int id = toInt(words[5]),
                                    wage = toInt(words[6]);
                                if (validateInt(id) == -999 || validateInt(wage) == -999)
                                    break;
                                if (validateId(id, corporateCustomers, retailCustomers, operators) == -999)
                                    break;
                                operators[opCtr] = new Operator(words[1], words[2], words[3], words[4], id, wage);
                                opCtr++;
                            }
                        }
                        case "retail_customer" -> {
                            if (words.length == 7) {
                                int id = toInt(words[5]),
                                    opId = toInt(words[6]);
                                if (validateInt(id) == -999 || validateInt(opId) == -999)
                                    break;
                                if (validateId(id, corporateCustomers, retailCustomers, operators) == -999)
                                    break;
                                retailCustomers[rCustCtr] = new RetailCustomer(words[1], words[2], words[3], words[4], id, opId);
                                rCustCtr++;
                            }
                        }
                        case "corporate_customer" -> {
                            if (words.length == 8) {
                                int id = toInt(words[5]),
                                    opId = toInt(words[6]);
                                if (validateInt(id) == -999 || validateInt(opId) == -999)
                                    break;
                                if (validateId(id, corporateCustomers, retailCustomers, operators) == -999)
                                    break;
                                corporateCustomers[cCustCtr] = new CorporateCustomer(words[1], words[2], words[3], words[4], toInt(words[5]), toInt(words[6]), words[7]);
                                cCustCtr++;
                            }
                        }
                    }
                }
            }
        }

        for (RetailCustomer retailCustomer : retailCustomers)
            if (retailCustomer != null)
                retailCustomer.defineOrders(orders);

        for (CorporateCustomer corporateCustomer : corporateCustomers)
            if (corporateCustomer != null)
                corporateCustomer.defineOrders(orders);

        for (Operator operator : operators) {
            if (operator != null) {
                operator.defineCustomers(retailCustomers);
                operator.defineCustomers(corporateCustomers);
            }
        }

        System.out.print("Please enter your ID: ");
        String id = scanner.nextLine();

        int isFound = searchAndFind(toInt(id), corporateCustomers, retailCustomers, operators);

        if (isFound == -999)
            System.out.printf("There is no customer/operator with ID %s.\nPlease try again.\n", id);
    }
}